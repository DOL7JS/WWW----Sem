create definer = root@localhost trigger triggerDeleteGoods
    before delete
    on goods
    for each row
BEGIN
        DECLARE done INT DEFAULT FALSE;
        DECLARE v_color VARCHAR(20);
        DECLARE v_image VARCHAR(150);
        DECLARE v_order INT;
        DECLARE v_quantity INT;
        DECLARE v_sale INT;
        DECLARE v_price INT;
        DECLARE v_isInOrder INT DEFAULT 0;

        DECLARE v_size VARCHAR(20);
        DECLARE cur1 CURSOR FOR SELECT size,quantity,order_id_order FROM db_dev.ordered_goods WHERE goods_id_goods = old.id_goods ;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
        SELECT image INTO v_image FROM db_dev.goods WHERE id_goods=old.id_goods LIMIT 1;
        SELECT REPLACE(v_image,'imgs_goods','deleted_goods') INTO v_image FROM dual;
        SELECT color INTO v_color FROM db_dev.attribute WHERE goods_id_goods=old.id_goods LIMIT 1;
        SELECT sale INTO v_sale FROM db_dev.attribute WHERE goods_id_goods=old.id_goods LIMIT 1;
        SELECT COUNT(*) INTO v_isInOrder FROM ordered_goods WHERE goods_id_goods=old.id_goods;
        OPEN cur1;
        DELETE FROM db_dev.ATTRIBUTE WHERE GOODS_id_goods=old.id_goods;
        DELETE FROM db_dev.GOODS_CATEGORY WHERE GOODS_id_goods=old.id_goods;
        DELETE FROM ordered_goods WHERE goods_id_goods = old.id_goods;
        SET v_price = old.price;
        IF v_isInOrder != 0 THEN
            IF v_sale IS NOT NULL THEN
                SET v_price = old.price*(1-(v_sale/100));
            end if ;
            read_loop: LOOP
                FETCH cur1 INTO v_size, v_quantity,v_order;
                IF done THEN
                    LEAVE read_loop;
                END IF;
                INSERT INTO db_dev.deleted_goods ( id_goods, name, price, color, image,order_id_order,quantity,size)VALUES (OLD.id_goods, OLD.name, v_price, v_color, v_image, v_order, v_quantity,v_size);
            end loop read_loop;
            CLOSE cur1;
        end if;
    END;

